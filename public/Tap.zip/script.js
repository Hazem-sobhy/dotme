async function load(){

const res = await fetch("/api/data")
const data = await res.json()

/* profile */

document.getElementById("name").innerText = data.profile.name
document.getElementById("title").innerText = data.profile.career

document.getElementById("profile").src = data.profile.image
document.getElementById("background").src = data.profile.background

/* phone */

document.getElementById("phoneBtn").href = "tel:"+data.profile.phone

/* email */

document.getElementById("emailBtn").href = "mailto:"+data.profile.email

/* links */

const container = document.getElementById("links")

container.innerHTML=""

data.links.forEach(link=>{

const el = document.createElement("a")

el.href = link.url
el.className="link"

el.innerHTML = `
<img src="${getIcon(link.name)}">
<span>${link.name}</span>
`

container.appendChild(el)

})

}

load()


/* ================= icons ================= */

function getIcon(name){

name = name.toLowerCase()

if(name==="whatsapp")
return "https://cdn-icons-png.flaticon.com/512/733/733585.png"

if(name==="linkedin")
return "https://cdn-icons-png.flaticon.com/512/174/174857.png"

if(name==="gmail")
return "https://cdn-icons-png.flaticon.com/512/281/281769.png"

if(name==="telegram")
return "https://cdn-icons-png.flaticon.com/512/2111/2111646.png"

if(name==="github")
return "https://cdn-icons-png.flaticon.com/512/733/733553.png"

if(name==="facebook")
return "https://cdn-icons-png.flaticon.com/512/733/733547.png"

if(name==="instagram")
return "https://cdn-icons-png.flaticon.com/512/2111/2111463.png"

return "https://cdn-icons-png.flaticon.com/512/565/565547.png"

}


/* ================= save contact ================= */

function saveContact(){

const name=document.getElementById("name").innerText
const phone=document.getElementById("phoneBtn").href.replace("tel:","")

const vcard = `
BEGIN:VCARD
VERSION:3.0
FN:${name}
TEL:${phone}
END:VCARD
`

const blob = new Blob([vcard],{type:"text/vcard"})

const link=document.createElement("a")

link.href = URL.createObjectURL(blob)
link.download = "contact.vcf"

link.click()

}


/* ================= MENU ================= */

function toggleMenu(){

const menu = document.getElementById("menuDropdown")
const share = document.getElementById("shareMenu")

/* اقفل الشير */

share.style.display="none"

/* toggle menu */

menu.style.display =
menu.style.display==="block" ? "none":"block"

}


/* ================= SHARE ================= */

function toggleShare(){

const share=document.getElementById("shareMenu")
const menu=document.getElementById("menuDropdown")

/* اقفل المينيو */

menu.style.display="none"

/* toggle share */

share.style.display =
share.style.display==="block" ? "none":"block"

}


/* ================= copy link ================= */

function copyLink(){

navigator.clipboard.writeText(window.location.href)

showToast("Link copied")

}

function showToast(message){

let toast=document.getElementById("toast")

if(!toast){

toast=document.createElement("div")

toast.id="toast"

document.body.appendChild(toast)

}

toast.innerText=message

toast.classList.add("show")

setTimeout(()=>{
toast.classList.remove("show")
},2000)

}


/* ================= QR ================= */

function showQR(){

const modal=document.getElementById("qrModal")
const img=document.getElementById("qrImage")

img.src =
"https://api.qrserver.com/v1/create-qr-code/?size=250x250&data="
+encodeURIComponent(window.location.href)

modal.style.display="flex"

}

function closeQR(){

document.getElementById("qrModal").style.display="none"

}

async function shareQR(){

const img=document.getElementById("qrImage")

const response = await fetch(img.src)

const blob = await response.blob()

const file = new File([blob], "profile-qr.png", {type:"image/png"})

if(navigator.share){

navigator.share({

files:[file],

title:"My Profile QR"

})

}else{

/* fallback download */

const link=document.createElement("a")

link.href=img.src

link.download="profile-qr.png"

link.click()

}

}


/* ================= native share ================= */

function nativeShare(){

if(navigator.share){

navigator.share({
title:"My Profile",
url:window.location.href
})

}else{

copyLink()

}

}


/* ================= close menus when clicking outside ================= */

document.addEventListener("click",function(e){

const menu = document.getElementById("menuDropdown")
const share = document.getElementById("shareMenu")

if(!e.target.closest(".top-bar")){

menu.style.display="none"
share.style.display="none"

}

})